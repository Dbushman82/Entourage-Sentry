ENTOURAGE SENTRY NETWORK SCANNER
==============================
Version 1.2.3 for Windows

INSTALLATION INSTRUCTIONS:
1. Extract all files from this ZIP archive
2. Right-click on EntourageSentryScanner.exe and select "Run as administrator"
3. Follow the on-screen instructions to scan your network
4. Save the scan results file (.json or .xml)
5. Upload the scan results in the Entourage Sentry web portal

SYSTEM REQUIREMENTS:
- Windows 10/11 (64-bit)
- .NET Framework 4.7.2 or higher
- Administrator privileges
- 200MB free disk space

SUPPORT:
For assistance, contact Entourage IT support at:
Email: support@entourageit.com
Phone: (800) 555-1234

© 2025 Entourage IT - Enterprise Network Security Scanner
