ENTOURAGE SENTRY NETWORK SCANNER
==============================
Version 1.2.1 for macOS

INSTALLATION INSTRUCTIONS:
1. Extract all files from this ZIP archive
2. Open the extracted folder and double-click on EntourageSentryScanner.app
3. Follow the on-screen instructions to scan your network
4. Save the scan results file (.json or .xml)
5. Upload the scan results in the Entourage Sentry web portal

SYSTEM REQUIREMENTS:
- macOS 11 Big Sur or higher
- Intel or Apple Silicon
- Admin privileges
- 300MB free disk space

SUPPORT:
For assistance, contact Entourage IT support at:
Email: support@entourageit.com
Phone: (800) 555-1234

© 2025 Entourage IT - Enterprise Network Security Scanner
